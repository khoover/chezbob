HASP/Hardlock Daemon install script (July 2004)
===============================================

Use this script to install the aksusbd daemon on your system. The
script will start aksusbd and configure it to launch every time the
system starts up.

This is the first release of the install script.

System Requirements
-------------------

RedHat 8.x or 9.x
SuSE 8.x or 9.x

Installation Instructions
-------------------------

1. Copy the akasusbd executable file into the same
   directory containing the install scripts.
2. Log in as root.
3. Execute the dinst script.

